//Try it #1
// $(document).ready(function(){
//     $("div").click(function(){
//         $(this).hide();
//     });
// });

// Try it #2
// $(document).ready(function(){
//     $("h1").click(function(){
//         $(this).addClass("blue");
//     });
// });

//Try it #3
// $(document).ready(function(){
//     $("h1").click(function(){
//         $(this).toggleClass("blue");
//     });
// });

//Try it #4
// $(document).ready(function(){
//     $("header").click(function(){
//         $(this).css("color", "purple");
//     });
// });

//Example #1
// $(document).ready(function(){
//     $(".p1").hover(function(){
//         $(this).css("font-family", "Times New Roman");
//     }, function(){
//         $(this).css("font-family", "Georgia");
//     });
// });

//Example #2
// $(document).ready(function(){
//     $("button").click(function(){
//         $(".pets").hide();
//     });
// });

//Example #3
// $(document).ready(function(){    
//     $("#rainbows").dblclick(function(){
//         alert("You double clicked me!");
//     });
// });

//Example #4
// $(document).ready(function(){    
//     $("input").focus(function(){
//        $(this).css("background-color", "lightblue");
//     });
// });

//Example #5
// $(document).ready(function(){
//     $("input").keyup(function(){
//         $(this).css("color", "red");
//     });
// });
